import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class JConnect {
	public static void main(String[] args){
		 
		String url ="jdbc:oracle:thin:FORMATION_ESB/FORMATION_ESB@localhost:1521:xe"; 
	    try { 
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			Connection con = DriverManager.getConnection(url, "FORMATION_ESB", "FORMATION_ESB"); 
	  		Statement stmt = con.createStatement( 
	        ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); 
	        ResultSet result = stmt.executeQuery ("SELECT TITLE FROM CD");          
	    	System.out.println("Got results:"); 
	        while(result.next()) { // process results one row at a time 
	           String val = result.getString(1); 
	    		System.out.println("val = " + val); 
	         } 
	        System.out.println("Connect success");
			} 
	       catch( Exception e ) { 
	         System.out.println("Failed to load oracle driver."); 
	         return; 
	       } 
	}
}
